package com.portfolio.MPB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MpbApplicationTests {

	@Test
	void contextLoads() {
	}

}
