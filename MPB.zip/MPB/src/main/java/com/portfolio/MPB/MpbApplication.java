package com.portfolio.MPB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpbApplication.class, args);
	}

}
